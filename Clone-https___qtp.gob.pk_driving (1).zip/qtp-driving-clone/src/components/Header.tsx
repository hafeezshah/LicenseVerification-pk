import { useState } from 'react';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const handleSubmenuToggle = (submenu: string) => {
    if (activeSubmenu === submenu) {
      setActiveSubmenu(null);
    } else {
      setActiveSubmenu(submenu);
    }
  };

  return (
    <div className="header bg-qtp-darkBlue text-white py-4 px-6 flex justify-between items-center">
      <div className="logo">
        <a href="/">
          <img src="/images/nav-logo.png" alt="Quetta Traffic Police" className="h-14" />
        </a>
      </div>

      <div className="menuIcon md:hidden" onClick={toggleMenu}>
        <span className="icon icon-bars overlay">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </span>
      </div>

      <div className={`links-header ${menuOpen ? 'block' : 'hidden'} md:block`}>
        <ul className="nav flex flex-col md:flex-row">
          <li className="nav-item relative">
            <a className="nav-link px-3 py-2 block hover:text-qtp-lightBlue" href="/">HOME</a>
          </li>

          <li className="nav-item relative">
            <a
              className="nav-link px-3 py-2 block hover:text-qtp-lightBlue flex items-center"
              href="/aboutus"
              onClick={(e) => {
                e.preventDefault();
                handleSubmenuToggle('about');
              }}
            >
              ABOUT
              <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            </a>
            {activeSubmenu === 'about' && (
              <ul className="submenu absolute bg-qtp-darkBlue min-w-40 z-10">
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/about/officer">Offices</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/about/aims">Aims</a></li>
              </ul>
            )}
          </li>

          <li className="nav-item relative">
            <a
              className="nav-link px-3 py-2 block text-qtp-lightBlue flex items-center font-bold"
              href="/driving"
              onClick={(e) => {
                e.preventDefault();
                handleSubmenuToggle('driving');
              }}
            >
              DRIVING LICENSE
              <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            </a>
            {activeSubmenu === 'driving' && (
              <ul className="submenu absolute bg-qtp-darkBlue min-w-40 z-10">
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/driving/verfication">License Verification</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/driving/learnerPermit">Learner Permit</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/driving/permanent">Permanent LICENSE</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/driving/international">International LICENSE</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/driving/duplicate">Duplicate LICENSE</a></li>
              </ul>
            )}
          </li>

          <li className="nav-item relative">
            <a
              className="nav-link px-3 py-2 block hover:text-qtp-lightBlue flex items-center"
              href="/traffic"
              onClick={(e) => {
                e.preventDefault();
                handleSubmenuToggle('traffic');
              }}
            >
              TRAFFIC
              <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            </a>
            {activeSubmenu === 'traffic' && (
              <ul className="submenu absolute bg-qtp-darkBlue min-w-40 z-10">
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/traffic/mangement">Traffic Management</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/traffic/problem">Traffic Problems</a></li>
                <li><a className="block px-4 py-2 hover:text-qtp-lightBlue" href="/traffic/challanfine">Challan/fine</a></li>
              </ul>
            )}
          </li>

          <li className="nav-item">
            <a className="nav-link px-3 py-2 block hover:text-qtp-lightBlue" href="/contact">CONTACT US</a>
          </li>
        </ul>

        <div className="flex md:ml-4">
          <div className="onlineappointbtn mx-1">
            <a
              href="http://fm.qtp.gob.pk/index.html"
              className="onlineappointbtn-link bg-white text-qtp-darkBlue px-3 py-1 rounded-full text-sm font-medium"
              target="_blank"
              rel="noopener noreferrer"
            >
              FM 88.6
            </a>
          </div>

          <div className="onlineappointbtn mx-1">
            <a
              href="/driving"
              className="onlineappointbtn-link bg-white text-qtp-darkBlue px-3 py-1 rounded-full text-sm font-medium"
            >
              Online Appointment
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
