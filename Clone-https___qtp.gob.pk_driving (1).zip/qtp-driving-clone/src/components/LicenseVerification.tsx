import { useState } from 'react';

const LicenseVerification = () => {
  const [cnicNumber, setCnicNumber] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const handleCnicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow numbers and format as xxxxx-xxxxxxx-x
    const value = e.target.value.replace(/[^0-9]/g, '');

    if (value.length <= 13) {
      // Format CNIC with dashes
      if (value.length <= 5) {
        setCnicNumber(value);
      } else if (value.length <= 12) {
        setCnicNumber(`${value.slice(0, 5)}-${value.slice(5)}`);
      } else {
        setCnicNumber(`${value.slice(0, 5)}-${value.slice(5, 12)}-${value.slice(12)}`);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);

    // Simulate verification process
    setTimeout(() => {
      setIsVerifying(false);

      // In a real application, you would handle the verification result here
      alert('This is a demo. In a real application, this would verify your license.');
    }, 1500);
  };

  return (
    <div className="license-verification-container">
      {/* Hero section with background image */}
      <div className="tp-img relative h-40 flex items-center justify-start bg-qtp-darkBlue"
          style={{
            backgroundImage: 'url(/images/background.png)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
          }}>
        <div className="head container mx-auto px-6">
          <h1 className="text-3xl font-bold text-white">LICENSE VERIFICATION</h1>
        </div>
      </div>

      {/* Verification form */}
      <div className="container mx-auto py-8 px-4">
        <div className="wrapper bg-white rounded-lg shadow-lg max-w-xl mx-auto overflow-hidden">
          <div className="title bg-qtp-darkBlue text-white text-xl font-semibold py-4 px-6 text-center">
            License Verification
          </div>

          <form onSubmit={handleSubmit} className="py-6 px-8">
            <div className="mb-6">
              <input
                type="text"
                placeholder="Enter CNIC Number"
                className="w-full px-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-qtp-lightBlue"
                value={cnicNumber}
                onChange={handleCnicChange}
                required
              />
            </div>

            <div className="recaptachdesign mb-6">
              <div className="g-recaptcha border border-gray-200 rounded p-4 flex justify-center">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="robot-check"
                    className="mr-2 h-5 w-5"
                  />
                  <label htmlFor="robot-check" className="text-gray-600">
                    I'm not a robot
                  </label>
                  <div className="ml-4">
                    <img src="https://ext.same-assets.com/2548793356/916436847.png" alt="reCAPTCHA" className="h-10" />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                className={`bg-qtp-darkBlue hover:bg-blue-700 text-white font-bold py-2 px-12 rounded-full ${isVerifying ? 'opacity-70 cursor-not-allowed' : ''}`}
                disabled={isVerifying}
              >
                {isVerifying ? 'Verifying...' : 'Verify'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LicenseVerification;
