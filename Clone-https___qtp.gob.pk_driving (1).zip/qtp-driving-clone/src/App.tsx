import Header from './components/Header';
import Footer from './components/Footer';
import LicenseVerification from './components/LicenseVerification';
import './App.css';

function App() {
  return (
    <div className="main-container flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <LicenseVerification />
      </main>
      <Footer />
    </div>
  );
}

export default App;
